package game.gui;


import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

	public class Controllergamemode implements Initializable{
	 private Stage stage;
	 private Scene scene;
	 private Parent root;
	 @FXML
	 private AnchorPane anchorpane;
	 
	public void Easy(ActionEvent x) throws IOException{
		 root = FXMLLoader.load(getClass().getResource("PreEasy.fxml"));
		 stage = (Stage)((Node)x.getSource()).getScene().getWindow();
		 scene = new Scene(root);
		 stage.setScene(scene);
		 stage.show();
		 
	 }
	 public void Hard(ActionEvent y) throws IOException{
		 root = FXMLLoader.load(getClass().getResource("PreHard.fxml"));
		 stage = (Stage)((Node)y.getSource()).getScene().getWindow();
		 scene = new Scene(root);
		 stage.setScene(scene);
		 stage.show();
		 
	 }
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		FadeTransition fadein = new FadeTransition();
		 fadein.setDuration(Duration.millis(2000));
		 fadein.setNode(anchorpane);
		 fadein.setFromValue(0);
		 fadein.setToValue(1);
		 fadein.play();
		
	}
}
