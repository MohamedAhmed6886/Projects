package game.gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Controller {
 private Stage stage;
 private Scene scene;
 private Parent root;
 @FXML
 private AnchorPane anchorpane;
 
/* public void start(ActionEvent x) throws IOException{
	 makeFadeOut();
	 root = FXMLLoader.load(getClass().getResource("Gamemode.fxml"));
	 stage = (Stage)((Node)x.getSource()).getScene().getWindow();
	 scene = new Scene(root);
	 stage.setScene(scene);
	 stage.show();
	 
 }
 */
 
 public void next(Stage primaryStage) throws IOException {
	 FadeTransition fadeout = new FadeTransition();
	 fadeout.setDuration(Duration.millis(500));
	 fadeout.setNode(anchorpane);
	 fadeout.setFromValue(1);
	 fadeout.setToValue(0);
	 fadeout.setOnFinished((ActionEvent e) ->{
		 try {
			root = (AnchorPane) FXMLLoader.load(getClass().getResource("Gamemode.fxml"));
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		 scene = primaryStage.getScene();
		 stage = (Stage)(primaryStage.getScene().getWindow());
		 scene = new Scene(root);
		 stage.setScene(scene);
		 stage.show();
	 });
	 fadeout.play();
	 }
 public void makeFadeOut() {
	 FadeTransition fadeout = new FadeTransition();
	 fadeout.setDuration(Duration.millis(2000));
	 fadeout.setNode(anchorpane);
	 fadeout.setFromValue(1);
	 fadeout.setToValue(0);
	 fadeout.play();
 }

}
