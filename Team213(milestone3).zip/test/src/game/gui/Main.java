package game.gui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;


public class Main extends Application implements Initializable{
	@Override
	public void start(Stage primaryStage) {
		try {
			FXMLLoader loader = new FXMLLoader (getClass().getResource("Main.fxml"));
			Parent root = loader.load();
			Controller controllerkey = loader.getController();
			Scene scenemain = new Scene(root);
			scenemain.setOnKeyPressed(new EventHandler<KeyEvent>() {

				public void handle(KeyEvent x) {
					if (x.getCode()==KeyCode.SPACE)
						try {
							controllerkey.next(primaryStage);
						} catch (IOException e) {
							e.printStackTrace();
						}
				}
				
			});
			String css = this.getClass().getResource("application.css").toExternalForm();
			scenemain.getStylesheets().add(css);
			primaryStage.setResizable(false);
			
			
			
			primaryStage.setScene(scenemain);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		
	}
}
