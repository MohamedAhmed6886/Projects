package game.gui;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import game.engine.Battle;
import game.engine.exceptions.InsufficientResourcesException;
import game.engine.exceptions.InvalidLaneException;
import game.engine.lanes.Lane;
import game.engine.titans.AbnormalTitan;
import game.engine.titans.ArmoredTitan;
import game.engine.titans.ColossalTitan;
import game.engine.titans.PureTitan;
import game.engine.titans.Titan;
import game.engine.weapons.WeaponRegistry;
import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Controllerhard implements Initializable{
	
	
	private Battle battle;
	private AnchorPane lane1pane;
	private AnchorPane lane2pane;
	private AnchorPane lane3pane;
	private AnchorPane lane4Pane;
	private AnchorPane lane5Pane;
	
	private ArrayList<TitanGui> titansguilist;
	private ArrayList<Titan> templist;
	private Alert x;
	private WeaponRegistry Wname1;
	private WeaponRegistry Wname2;
	private WeaponRegistry Wname3;
	private WeaponRegistry Wname4;
	
	
@FXML	 
private Label l1level;
@FXML	 
private Label l2level;
@FXML	 
private Label l3level;
@FXML
private Label l4level;
@FXML
private Label l5level;
@FXML	 
 private Label w1health;
 @FXML
 private Label w2health;
 @FXML
 private Label w3health;
 @FXML
 private Label w4health;
 @FXML
 private Label w5health;
 @FXML
 private Label nturns;
 @FXML
 private Label phaseearly;
 @FXML
 private Label phaseintense;
 @FXML
 private Label phaseGrumbling;
 
 
 @FXML
 private Label curScore;
 @FXML
 private Label curResources;
 @FXML
 private Label weaponName1;
 @FXML
 private Label weaponName2;
 @FXML
 private Label weaponName3;
 @FXML
 private Label weaponName4;
 @FXML
 private Label weaponType1;
 @FXML
 private Label weaponType2;
 @FXML
 private Label weaponType3;
 @FXML
 private Label weaponType4;
 @FXML
 private Label weaponPrice1;
 @FXML
 private Label weaponPrice2;
 @FXML
 private Label weaponPrice3;
 @FXML
 private Label weaponPrice4;
 @FXML
 private Label weaponDamage1;
 @FXML
 private Label weaponDamage2;
 @FXML
 private Label weaponDamage3;
 @FXML
 private Label weaponDamage4;
 @FXML
 private AnchorPane ScenePane;
 @FXML
 private AnchorPane Weapon1;
 @FXML
 private AnchorPane Weapon2;
 @FXML
 private AnchorPane Weapon3;
 @FXML
 private AnchorPane Weapon4;
 @FXML
 private Button bWeapon1;
 @FXML
 private Button bWeapon2;
 @FXML
 private Button bWeapon3;
 @FXML
 private Button bWeapon4;
 @FXML
 private Button w3l1;
 @FXML
 private Button w3l2;
 @FXML
 private Button w3l3;
 @FXML
 private Button w3l4;
 @FXML
 private Button w3l5;
 @FXML
 private Button w2l1;
 @FXML
 private Button w2l2;
 @FXML
 private Button w2l3;
 @FXML
 private Button w2l4;
 @FXML
 private Button w2l5;
 @FXML
 private Button w1l1;
 @FXML
 private Button w1l2;
 @FXML
 private Button w1l3;
 @FXML
 private Button w1l4;
 @FXML
 private Button w1l5;
 @FXML
 private Button w4l1;
 @FXML
 private Button w4l2;
 @FXML
 private Button w4l3;
 @FXML
 private Button w4l4;
 @FXML
 private Button w4l5;
 @FXML
 private Label l1w1;
 int l1w1i;
 @FXML
 private Label l1w2;
 int l1w2i;
 @FXML
 private Label l1w3;
 int l1w3i;
 @FXML
 private Label l1w4;
 int l1w4i;
 @FXML
 private Label l2w1;
 int l2w1i;
 @FXML
 private Label l2w2;
 int l2w2i;
 @FXML
 private Label l2w3;
 int l2w3i;
 @FXML
 private Label l2w4;
 int l2w4i;
 @FXML
 private Label l3w1;
 int l3w1i;
 @FXML
 private Label l3w2;
 int l3w2i;
 @FXML
 private Label l3w3;
 int l3w3i;
 @FXML
 private Label l3w4;
 int l3w4i;
 @FXML
 private Label l4w1;
 int l4w1i;
 @FXML
 private Label l4w2;
 int l4w2i;
 @FXML
 private Label l4w3;
 int l4w3i;
 @FXML
 private Label l4w4;
 int l4w4i;
 @FXML
 private Label l5w1;
 int l5w1i;
 @FXML
 private Label l5w2;
 int l5w2i;
 @FXML
 private Label l5w3;
 int l5w3i;
 @FXML
 private Label l5w4;
 int l5w4i;

	 public void weapon1(ActionEvent e){
		 FadeTransition fadeout = new FadeTransition();
		 fadeout.setDuration(Duration.millis(1000));
		 fadeout.setNode(Weapon1);
		 fadeout.setFromValue(0);
		 fadeout.setToValue(1);
		 fadeout.play();
		 Weapon2.setOpacity(0);
		 Weapon3.setOpacity(0);
		 Weapon4.setOpacity(0);
	 }
	 public void weapon2(ActionEvent e){
		 FadeTransition fadeout = new FadeTransition();
		 fadeout.setDuration(Duration.millis(1000));
		 fadeout.setNode(Weapon2);
		 fadeout.setFromValue(0);
		 fadeout.setToValue(1);
		 fadeout.play();
		 Weapon1.setOpacity(0);
		 Weapon3.setOpacity(0);
		 Weapon4.setOpacity(0);
	 }
	 public void weapon3(ActionEvent e){
		 FadeTransition fadeout = new FadeTransition();
		 fadeout.setDuration(Duration.millis(1000));
		 fadeout.setNode(Weapon3);
		 fadeout.setFromValue(0);
		 fadeout.setToValue(1);
		 fadeout.play();
		 Weapon2.setOpacity(0);
		 Weapon1.setOpacity(0);
		 Weapon4.setOpacity(0);
	 }
	 public void weapon4(ActionEvent e){
		 FadeTransition fadeout = new FadeTransition();
		 fadeout.setDuration(Duration.millis(1000));
		 fadeout.setNode(Weapon4);
		 fadeout.setFromValue(0);
		 fadeout.setToValue(1);
		 fadeout.play();
		 Weapon2.setOpacity(0);
		 Weapon3.setOpacity(0);
		 Weapon1.setOpacity(0);
	 }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		try{
			 battle = new Battle(1,0,100,5,125);
			 titansguilist = new ArrayList<TitanGui>();
			 templist = new ArrayList<Titan>();
			 
			 w1health.setText(""+battle.getOriginalLanes().get(0).getLaneWall().getCurrentHealth());
			 w2health.setText(""+battle.getOriginalLanes().get(1).getLaneWall().getCurrentHealth());
			 w3health.setText(""+battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
			 w4health.setText(""+battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
			 w5health.setText(""+battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
			 
			 nturns.setText(""+battle.getNumberOfTurns());
			 
			 l1level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
			 l2level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
			 l3level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
			 l4level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
			 l5level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
			 
			 curScore.setText(""+battle.getScore());
			 curResources.setText(""+battle.getResourcesGathered());
			 weaponName1.setText(""+battle.getWeaponFactory().getWeaponShop().get(1).getName());
			 weaponType1.setText("PiercingCannon");
			 weaponPrice1.setText(""+battle.getWeaponFactory().getWeaponShop().get(1).getPrice());
			 weaponDamage1.setText(""+battle.getWeaponFactory().getWeaponShop().get(1).getDamage());
			 Wname1 = battle.getWeaponFactory().getWeaponShop().get(1);
			 bWeapon1.setText(Wname1.getName() +"\n" + "Price" + Wname1.getPrice() + "\n" + "Damage" + Wname1.getDamage());
			 
			 weaponName2.setText(""+battle.getWeaponFactory().getWeaponShop().get(2).getName());
			 weaponType2.setText("SniperCannon");
			 weaponPrice2.setText(""+battle.getWeaponFactory().getWeaponShop().get(2).getPrice());
			 weaponDamage2.setText(""+battle.getWeaponFactory().getWeaponShop().get(2).getDamage());
			 Wname2 = battle.getWeaponFactory().getWeaponShop().get(2);
			 bWeapon2.setText(Wname2.getName() +"\n" + "Price" + Wname2.getPrice() + "\n" + "Damage" + Wname2.getDamage());
			 
			 weaponName3.setText(""+battle.getWeaponFactory().getWeaponShop().get(3).getName());
			 weaponType3.setText("VolleySpreadCannon");
			 weaponPrice3.setText(""+battle.getWeaponFactory().getWeaponShop().get(3).getPrice());
			 weaponDamage3.setText(""+battle.getWeaponFactory().getWeaponShop().get(3).getDamage());
			 Wname3 = battle.getWeaponFactory().getWeaponShop().get(3);
			 bWeapon3.setText(Wname3.getName() +"\n" + "Price" + Wname3.getPrice() + "\n" + "Damage" + Wname3.getDamage());
			 

			 weaponName4.setText(""+battle.getWeaponFactory().getWeaponShop().get(4).getName());
			 weaponType4.setText("WallTrap");
			 weaponPrice4.setText(""+battle.getWeaponFactory().getWeaponShop().get(4).getPrice());
			 weaponDamage4.setText(""+battle.getWeaponFactory().getWeaponShop().get(4).getDamage());
			 Wname4 = battle.getWeaponFactory().getWeaponShop().get(4);
			 bWeapon4.setText(Wname4.getName() +"\n" + "Price" + Wname4.getPrice() + "\n" + "Damage" + Wname4.getDamage());
			 
			 
			 lane1pane = new AnchorPane();
			 lane1pane.resize(10, 10);
			 lane1pane.setPrefWidth(100);
			 lane1pane.setPrefHeight(100);
			 lane1pane.setLayoutX(30);
			 lane1pane.setLayoutY(60);
			 
			 lane2pane = new AnchorPane();
			 lane2pane.resize(10, 10);
			 lane2pane.setPrefWidth(100);
			 lane2pane.setPrefHeight(100);
			 lane2pane.setLayoutX(30);
			 lane2pane.setLayoutY(160);
			 
			 lane3pane = new AnchorPane();
			 lane3pane.resize(10, 10);
			 lane3pane.setPrefWidth(100);
			 lane3pane.setPrefHeight(100);
			 lane3pane.setLayoutX(30);
			 lane3pane.setLayoutY(260);
			 
			 lane4Pane = new AnchorPane();
			 lane4Pane.resize(10, 10);
			 lane4Pane.setPrefWidth(100);
			 lane4Pane.setPrefHeight(100);
			 lane4Pane.setLayoutX(20);
			 lane4Pane.setLayoutY(360);
			 
			 lane5Pane = new AnchorPane();
			 lane5Pane.resize(10, 10);
			 lane5Pane.setPrefWidth(100);
			 lane5Pane.setPrefHeight(100);
			 lane5Pane.setLayoutX(20);
			 lane5Pane.setLayoutY(460);
			 
			 ScenePane.getChildren().add(lane1pane);
			 ScenePane.getChildren().add(lane2pane);
			 ScenePane.getChildren().add(lane3pane);
			 ScenePane.getChildren().add(lane4Pane);
			 ScenePane.getChildren().add(lane5Pane);

		 }
		catch(IOException e1){
			 alert(e1.getMessage(), "An error occured, try e1.printstack in initializable catch");
		 }
	}
	
	
	
	
	
	
	public void w1l1meth(ActionEvent e) {
		wlmeth(1,1);
		l1w1i++;
		l1w1.setText(""+l1w1i);
	}
	public void w1l2meth(ActionEvent e) {
		wlmeth(1,2);
		l2w1i++;
		l2w1.setText(""+l2w1i);
	}
	public void w1l3meth(ActionEvent e) {
		wlmeth(1,3);
		l3w1i++;
		l3w1.setText(""+l3w1i);
	}
	public void w1l4meth(ActionEvent e) {
		wlmeth(1,4);
		l4w1i++;
		l4w1.setText(""+l4w1i);
	}
	public void w1l5meth(ActionEvent e) {
		wlmeth(1,5);
		l5w1i++;
		l5w1.setText(""+l5w1i);
	}
	
	
	public void w2l1meth(ActionEvent e) {
		wlmeth(2,1);
		l1w2i++;
		l1w2.setText(""+l1w2i);
	}
	public void w2l2meth(ActionEvent e) {
		wlmeth(2,2);
		l2w2i++;
		l2w2.setText(""+l2w2i);
	}
	public void w2l3meth(ActionEvent e) {
		wlmeth(2,3);
		l3w2i++;
		l3w2.setText(""+l3w2i);
	}
	public void w2l4meth(ActionEvent e) {
		wlmeth(2,4);
		l4w2i++;
		l4w2.setText(""+l4w2i);
	}
	public void w2l5meth(ActionEvent e) {
		wlmeth(2,5);
		l5w2i++;
		l5w2.setText(""+l5w2i);
	}
	
	
	public void w3l1meth(ActionEvent e) {
		wlmeth(3,1);
		l1w3i++;
		l1w3.setText(""+l1w3i);
	}
	public void w3l2meth(ActionEvent e) {
		wlmeth(3,2);
		l2w3i++;
		l2w3.setText(""+l2w3i);
	}
	public void w3l3meth(ActionEvent e) {
		wlmeth(3,3);
		l3w3i++;
		l3w3.setText(""+l3w3i);
	}
	public void w3l4meth(ActionEvent e) {
		wlmeth(3,4);
		l4w3i++;
		l4w3.setText(""+l4w3i);
	}
	public void w3l5meth(ActionEvent e) {
		wlmeth(3,5);
		l5w3i++;
		l5w3.setText(""+l5w3i);
	}
	
	
	public void w4l1meth(ActionEvent e) {
		wlmeth(4,1);
		l1w4i++;
		l1w4.setText(""+l1w4i);
	}
	public void w4l2meth(ActionEvent e) {
		wlmeth(4,2);
		l2w4i++;
		l2w4.setText(""+l2w4i);
	}
	public void w4l3meth(ActionEvent e) {
		wlmeth(4,3);
		l3w4i++;
		l3w4.setText(""+l3w4i);
	}
	public void w4l4meth(ActionEvent e) {
		wlmeth(4,4);
		l4w4i++;
		l4w4.setText(""+l4w4i);
	}
	public void w4l5meth(ActionEvent e) {
		wlmeth(4,5);
		l5w4i++;
		l5w4.setText(""+l5w4i);
	}
	
	public void wlmeth(int code, int lanenum){
		 try {
			 AnchorPane z = getlane();
			 fillturn();
			 battle.purchaseWeapon(code, battle.getOriginalLanes().get(lanenum-1));
			 endgame(z);
			 moveremove();
			 deploytitan(z);
			 update();
			 	 
		} catch (InsufficientResourcesException e1) {
             alert(e1.getMessage(), "Cannot Purchase");
			
		} catch (InvalidLaneException e1) {

			alert(e1.getMessage(), "Cannot deploy the weapon,the lanewall is destroyed");
		}
	}
	public void passturn() {
		 AnchorPane z = getlane();
		 fillturn();
		 battle.passTurn();
		 endgame(z);
		 moveremove();
		 deploytitan(z);
		 update();
	}
		 
		 
	
	public AnchorPane getlane() {
		AnchorPane z = null;
		Lane l=battle.getLanes().peek();
		if (l==battle.getOriginalLanes().get(0))
			z=lane1pane;
		if (l==battle.getOriginalLanes().get(1))
			z=lane2pane;
		if (l==battle.getOriginalLanes().get(2))
			z=lane3pane;
		if (l==battle.getOriginalLanes().get(3))
			z=lane4Pane;
		if (l==battle.getOriginalLanes().get(4))
			z=lane5Pane;
		return z;
	}
	public void moveremove() {
		for(int i=0;i<titansguilist.size();i++) {
			titansguilist.get(i).moveremove();
			if (titansguilist.get(i).getTitan().getCurrentHealth()==0) {
				titansguilist.remove(i);
			}
		}
	}
	public void deploytitan(AnchorPane z) {
		for (int i=0;i<templist.size();i++) {
		TitanGui y = new TitanGui(templist.get(i));
		titansguilist.add(y);
		
		z.getChildren().add(y.getTitanpane());

		}
		templist.clear();
	}
	public void fillturn() {
		int z=battle.getNumberOfTitansPerTurn();
		for(int i=0;i<z;i++) {
			if (battle.getApproachingTitans().isEmpty())
				battle.refillApproachingTitans();
			z=z-1;
			i=0;
			templist.add(battle.getApproachingTitans().get(i));
		}
	}
	public void endgame(AnchorPane z){ // use end scene later instead of alert
		if (battle.isGameOver()) {
		  alert1();
		}
		else {
		for(int i=0;i<battle.getOriginalLanes().size();i++) {
		if (battle.getOriginalLanes().get(i).isLaneLost()) {
			if (i==0) {
				
				if (z==lane1pane) {
					z=getlane();
				}
				lane1pane.getChildren().clear();
			}
			else if (i==1) {
				if (z==lane2pane) {
					z=getlane();
				}
				lane2pane.getChildren().clear();
			}
			else if (i==2) {
				if (z==lane3pane)
					z=getlane();
				lane3pane.getChildren().clear();
			}
			else if (i==3) {
				if (z==lane4Pane)
					z=getlane();
				lane3pane.getChildren().clear();
			}
			else if (i==4) {
				if (z==lane5Pane)
					z=getlane();
				lane3pane.getChildren().clear();
			}
		}
			}
		}
	}
		// make new scene of the score you got, want to start again(go to gamemode in it)?endgame?
	
	public void alert(String y,String w) {
		x=new Alert(Alert.AlertType.ERROR);
		x.setTitle("Error");
		x.setHeaderText(w);
		x.setContentText(y); 
		x.show();
	}
	
	 Parent root;
	 Scene scene;
	 Stage stage;
	public void alert1() {
	        Alert alert = new Alert(Alert.AlertType.INFORMATION);
	        alert.setHeaderText("Game Over!");
	        alert.setContentText("Your score: " + battle.getScore());
	        
	        Button closeButton = new Button("CLOSE");
	        closeButton.setOnAction(e -> {
	        	try {
	        		root = FXMLLoader.load(getClass().getResource("End.fxml"));
	        	} catch (IOException e1) {
	        		e1.printStackTrace();
	        	}
	        	 stage = (Stage)((Node)e.getSource()).getScene().getWindow();
	        	 scene = new Scene(root);
	        	 stage.setScene(scene);
	        	 stage.show();
	        
	        });
	        
	        alert.getDialogPane().setExpandableContent(closeButton);

	        alert.showAndWait();
	    
	}
	
	
	 public void update() {
		 FadeTransition fadeout = new FadeTransition();
		 curScore.setText(""+battle.getScore());
		 curResources.setText(""+battle.getResourcesGathered());
		 w1health.setText(""+battle.getOriginalLanes().get(0).getLaneWall().getCurrentHealth());
		 w2health.setText(""+battle.getOriginalLanes().get(1).getLaneWall().getCurrentHealth());
		 w3health.setText(""+battle.getOriginalLanes().get(2).getLaneWall().getCurrentHealth());
		 w4health.setText(""+battle.getOriginalLanes().get(3).getLaneWall().getCurrentHealth());
		 w5health.setText(""+battle.getOriginalLanes().get(4).getLaneWall().getCurrentHealth());
		 
		 l1level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
		 l2level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
		 l3level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
		 l4level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
		 l5level.setText(""+battle.getOriginalLanes().get(0).getDangerLevel());
		 nturns.setText(""+battle.getNumberOfTurns());
		 
		 if(battle.getBattlePhase()==this.battle.getBattlePhase().GRUMBLING) {
			 fadeout.setDuration(Duration.millis(1000));
			 fadeout.setNode(phaseGrumbling);
			 fadeout.setFromValue(0);
			 fadeout.setToValue(1);
			 fadeout.play();
			 phaseearly.setOpacity(0);
		     phaseintense.setOpacity(0);
		 }
			 else {
		 if(battle.getBattlePhase()==this.battle.getBattlePhase().INTENSE) {
			 fadeout.setDuration(Duration.millis(1000));
			 fadeout.setNode(phaseintense);
			 fadeout.setFromValue(0);
			 fadeout.setToValue(1);
			 fadeout.play();
			 
			 phaseearly .setOpacity(0);
			 phaseGrumbling .setOpacity(0);
		 }
			 }
			 
		 
		 for (int i=0;i<titansguilist.size();i++) {
			 titansguilist.get(i).updatelabel();
		 }
	 }

}